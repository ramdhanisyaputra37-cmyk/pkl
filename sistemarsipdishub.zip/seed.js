// Menambahkan beberapa contoh data ke data/documents.json.
// Jalankan dengan: npm run seed
// Aman dijalankan lebih dari sekali (hanya menambah, tidak menghapus data lama).

const crypto = require('crypto');
const { readData, writeData } = require('./lib/store');

const now = new Date().toISOString();
const currentYear = new Date().getFullYear();

const samples = [
  {
    jenis: 'masuk',
    nomorUrut: 1,
    nomorBuku: `I/${currentYear}`,
    kode: 'UM',
    indeks: 'Undangan',
    uraianMasalah: 'Contoh: Undangan rapat koordinasi lalu lintas dari Polres setempat',
    tahun: currentYear,
    jumlah: 1,
    keterangan: ['Asli'],
  },
  {
    jenis: 'keluar',
    nomorUrut: 1,
    nomorBuku: `I/${currentYear}`,
    kode: 'HK',
    indeks: 'Surat Tugas',
    uraianMasalah: 'Contoh: Surat tugas survei uji kelaikan kendaraan angkutan umum',
    tahun: currentYear,
    jumlah: 2,
    keterangan: ['Asli', 'TTD'],
  },
  {
    jenis: 'masuk',
    nomorUrut: 2,
    nomorBuku: `I/${currentYear}`,
    kode: 'KU',
    indeks: 'Laporan',
    uraianMasalah: 'Contoh: Laporan retribusi parkir bulanan dari UPTD Perparkiran',
    tahun: currentYear,
    jumlah: 1,
    keterangan: ['Fotocopy'],
  },
];

(async () => {
  const existing = await readData();
  const seeded = samples.map((sample) => ({
    id: crypto.randomUUID(),
    ...sample,
    createdAt: now,
    updatedAt: now,
  }));
  await writeData([...existing, ...seeded]);
  console.log(`Berhasil menambahkan ${seeded.length} data contoh ke data/documents.json`);
})();
