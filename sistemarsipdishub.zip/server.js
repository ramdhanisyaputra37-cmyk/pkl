const express = require('express');
const path = require('path');
const crypto = require('crypto');
const { readData, writeData } = require('./lib/store');

const PORT = process.env.PORT || 3000;
const KETERANGAN_OPTIONS = ['Asli', 'Fotocopy', 'TTD'];

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function validatePayload(body) {
  const errors = [];

  const jenis = body.jenis === 'keluar' ? 'keluar' : body.jenis === 'masuk' ? 'masuk' : null;
  if (!jenis) errors.push('Jenis surat harus "masuk" atau "keluar".');

  const uraianMasalah = (body.uraianMasalah || '').toString().trim();
  if (!uraianMasalah) errors.push('Uraian masalah wajib diisi.');

  const tahun = Number(body.tahun);
  if (!Number.isInteger(tahun) || tahun < 1900 || tahun > 2200) {
    errors.push('Tahun tidak valid.');
  }

  const jumlah = Number(body.jumlah);
  if (!Number.isFinite(jumlah) || jumlah < 0) {
    errors.push('Jumlah tidak valid.');
  }

  const nomorUrut = Number(body.nomorUrut);
  if (!Number.isFinite(nomorUrut) || nomorUrut < 0) {
    errors.push('Nomor urut tidak valid.');
  }

  const keterangan = Array.isArray(body.keterangan)
    ? body.keterangan.filter((k) => KETERANGAN_OPTIONS.includes(k))
    : [];

  return {
    errors,
    value: {
      jenis,
      nomorUrut,
      nomorBuku: (body.nomorBuku || '').toString().trim(),
      kode: (body.kode || '').toString().trim(),
      indeks: (body.indeks || '').toString().trim(),
      uraianMasalah,
      tahun,
      jumlah,
      keterangan,
    },
  };
}

app.get('/api/documents', async (req, res) => {
  const data = await readData();
  let result = data;

  const { jenis, tahun, q } = req.query;
  if (jenis === 'masuk' || jenis === 'keluar') {
    result = result.filter((d) => d.jenis === jenis);
  }
  if (tahun) {
    result = result.filter((d) => String(d.tahun) === String(tahun));
  }
  if (q) {
    const needle = q.toString().toLowerCase();
    result = result.filter((d) =>
      [d.kode, d.indeks, d.uraianMasalah, d.nomorBuku]
        .filter(Boolean)
        .some((field) => field.toLowerCase().includes(needle))
    );
  }

  result = [...result].sort((a, b) => {
    if (b.tahun !== a.tahun) return b.tahun - a.tahun;
    if (b.nomorUrut !== a.nomorUrut) return b.nomorUrut - a.nomorUrut;
    return (b.createdAt || '').localeCompare(a.createdAt || '');
  });

  res.json(result);
});

app.get('/api/stats', async (req, res) => {
  const data = await readData();
  const currentYear = new Date().getFullYear();
  res.json({
    total: data.length,
    masuk: data.filter((d) => d.jenis === 'masuk').length,
    keluar: data.filter((d) => d.jenis === 'keluar').length,
    tahunIni: data.filter((d) => d.tahun === currentYear).length,
  });
});

app.post('/api/documents', async (req, res) => {
  const { errors, value } = validatePayload(req.body || {});
  if (errors.length) return res.status(400).json({ errors });

  const data = await readData();
  const now = new Date().toISOString();
  const doc = { id: crypto.randomUUID(), ...value, createdAt: now, updatedAt: now };
  data.push(doc);
  await writeData(data);
  res.status(201).json(doc);
});

app.put('/api/documents/:id', async (req, res) => {
  const { errors, value } = validatePayload(req.body || {});
  if (errors.length) return res.status(400).json({ errors });

  const data = await readData();
  const idx = data.findIndex((d) => d.id === req.params.id);
  if (idx === -1) return res.status(404).json({ errors: ['Data tidak ditemukan.'] });

  data[idx] = { ...data[idx], ...value, updatedAt: new Date().toISOString() };
  await writeData(data);
  res.json(data[idx]);
});

app.delete('/api/documents/:id', async (req, res) => {
  const data = await readData();
  const idx = data.findIndex((d) => d.id === req.params.id);
  if (idx === -1) return res.status(404).json({ errors: ['Data tidak ditemukan.'] });

  const [removed] = data.splice(idx, 1);
  await writeData(data);
  res.json(removed);
});

app.listen(PORT, () => {
  console.log(`Sistem Arsip Dishub berjalan di http://localhost:${PORT}`);
});
