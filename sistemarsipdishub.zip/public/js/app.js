(function () {
  'use strict';

  const state = {
    all: [],
    jenis: '',
    tahun: '',
    q: '',
    page: 1,
    pageSize: 25,
  };

  const el = {
    tableBody: document.getElementById('tableBody'),
    pagination: document.getElementById('pagination'),
    searchInput: document.getElementById('searchInput'),
    filterTahun: document.getElementById('filterTahun'),
    statTotal: document.getElementById('statTotal'),
    statMasuk: document.getElementById('statMasuk'),
    statKeluar: document.getElementById('statKeluar'),
    statTahunIni: document.getElementById('statTahunIni'),
    modalOverlay: document.getElementById('modalOverlay'),
    modalTitle: document.getElementById('modalTitle'),
    dataForm: document.getElementById('dataForm'),
    formError: document.getElementById('formError'),
    fieldId: document.getElementById('fieldId'),
    fieldNomorUrut: document.getElementById('fieldNomorUrut'),
    fieldNomorBuku: document.getElementById('fieldNomorBuku'),
    fieldKode: document.getElementById('fieldKode'),
    fieldIndeks: document.getElementById('fieldIndeks'),
    fieldUraian: document.getElementById('fieldUraian'),
    fieldTahun: document.getElementById('fieldTahun'),
    fieldJumlah: document.getElementById('fieldJumlah'),
  };

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  }

  function computeStats(all) {
    const currentYear = new Date().getFullYear();
    return {
      total: all.length,
      masuk: all.filter((d) => d.jenis === 'masuk').length,
      keluar: all.filter((d) => d.jenis === 'keluar').length,
      tahunIni: all.filter((d) => d.tahun === currentYear).length,
    };
  }

  function getFiltered() {
    let list = state.all;
    if (state.jenis) list = list.filter((d) => d.jenis === state.jenis);
    if (state.tahun) list = list.filter((d) => String(d.tahun) === String(state.tahun));
    if (state.q) {
      const needle = state.q.toLowerCase();
      list = list.filter((d) =>
        [d.kode, d.indeks, d.uraianMasalah, d.nomorBuku]
          .filter(Boolean)
          .some((field) => field.toLowerCase().includes(needle))
      );
    }
    return [...list].sort((a, b) => {
      if (b.tahun !== a.tahun) return b.tahun - a.tahun;
      if (b.nomorUrut !== a.nomorUrut) return b.nomorUrut - a.nomorUrut;
      return (b.createdAt || '').localeCompare(a.createdAt || '');
    });
  }

  function rowHtml(doc, rowNumber) {
    const badgeClass = doc.jenis === 'masuk' ? 'badge--masuk' : 'badge--keluar';
    const badgeText = doc.jenis === 'masuk' ? 'Masuk' : 'Keluar';
    return `
      <tr>
        <td>${rowNumber}</td>
        <td><span class="badge ${badgeClass}">${badgeText}</span></td>
        <td>${escapeHtml(doc.nomorUrut)}</td>
        <td>${escapeHtml(doc.nomorBuku)}</td>
        <td>${escapeHtml(doc.kode)}</td>
        <td>${escapeHtml(doc.indeks)}</td>
        <td class="uraian-cell">${escapeHtml(doc.uraianMasalah)}</td>
        <td>${escapeHtml(doc.tahun)}</td>
        <td>${escapeHtml(doc.jumlah)}</td>
        <td>${escapeHtml((doc.keterangan || []).join(', '))}</td>
        <td class="col-aksi">
          <div class="action-group">
            <button class="btn btn--ghost btn--small" data-action="edit" data-id="${doc.id}" type="button">Edit</button>
            <button class="btn btn--danger btn--small" data-action="delete" data-id="${doc.id}" type="button">Hapus</button>
          </div>
        </td>
      </tr>`;
  }

  function renderPagination(totalItems, totalPages) {
    if (!totalItems) {
      el.pagination.innerHTML = '';
      return;
    }
    el.pagination.innerHTML = `
      <button id="prevPage" type="button" ${state.page <= 1 ? 'disabled' : ''}>&laquo; Sebelumnya</button>
      <span>Halaman ${state.page} dari ${totalPages} (${totalItems} data)</span>
      <button id="nextPage" type="button" ${state.page >= totalPages ? 'disabled' : ''}>Berikutnya &raquo;</button>
    `;
    const prev = document.getElementById('prevPage');
    const next = document.getElementById('nextPage');
    if (prev) prev.addEventListener('click', () => { state.page -= 1; renderTable(); });
    if (next) next.addEventListener('click', () => { state.page += 1; renderTable(); });
  }

  function renderTable() {
    const filtered = getFiltered();
    const totalPages = Math.max(1, Math.ceil(filtered.length / state.pageSize));
    if (state.page > totalPages) state.page = totalPages;
    const start = (state.page - 1) * state.pageSize;
    const pageItems = filtered.slice(start, start + state.pageSize);

    if (!pageItems.length) {
      el.tableBody.innerHTML = '<tr><td colspan="11" class="empty-row">Tidak ada data yang cocok.</td></tr>';
    } else {
      el.tableBody.innerHTML = pageItems.map((doc, i) => rowHtml(doc, start + i + 1)).join('');
    }
    renderPagination(filtered.length, totalPages);
  }

  function renderStats() {
    const s = computeStats(state.all);
    el.statTotal.textContent = s.total;
    el.statMasuk.textContent = s.masuk;
    el.statKeluar.textContent = s.keluar;
    el.statTahunIni.textContent = s.tahunIni;
  }

  function renderYearOptions() {
    const years = [...new Set(state.all.map((d) => d.tahun))].sort((a, b) => b - a);
    const current = el.filterTahun.value;
    el.filterTahun.innerHTML = '<option value="">Semua Tahun</option>' +
      years.map((y) => `<option value="${y}">${y}</option>`).join('');
    if (years.map(String).includes(current)) el.filterTahun.value = current;
  }

  async function refresh() {
    try {
      const res = await fetch('/api/documents');
      state.all = await res.json();
    } catch (err) {
      console.error('Gagal memuat data:', err);
      state.all = [];
    }
    renderYearOptions();
    renderStats();
    renderTable();
  }

  // ---- Modal ----

  function suggestNextNomorUrut(jenis) {
    const year = Number(el.fieldTahun.value) || new Date().getFullYear();
    const relevant = state.all.filter((d) => d.jenis === jenis && d.tahun === year);
    const max = relevant.reduce((m, d) => Math.max(m, Number(d.nomorUrut) || 0), 0);
    return max + 1;
  }

  function refreshSuggestionIfAdding() {
    if (el.fieldId.value) return;
    const jenis = el.dataForm.querySelector('input[name="jenis"]:checked').value;
    el.fieldNomorUrut.value = suggestNextNomorUrut(jenis);
  }

  function openModal(doc) {
    el.dataForm.reset();
    el.formError.hidden = true;
    el.modalTitle.textContent = doc ? 'Edit Data' : 'Tambah Data';
    el.fieldId.value = doc ? doc.id : '';

    if (doc) {
      el.dataForm.querySelector(`input[name="jenis"][value="${doc.jenis}"]`).checked = true;
      el.fieldNomorUrut.value = doc.nomorUrut;
      el.fieldNomorBuku.value = doc.nomorBuku || '';
      el.fieldKode.value = doc.kode || '';
      el.fieldIndeks.value = doc.indeks || '';
      el.fieldUraian.value = doc.uraianMasalah || '';
      el.fieldTahun.value = doc.tahun;
      el.fieldJumlah.value = doc.jumlah;
      (doc.keterangan || []).forEach((k) => {
        const cb = el.dataForm.querySelector(`input[name="keterangan"][value="${k}"]`);
        if (cb) cb.checked = true;
      });
    } else {
      el.fieldTahun.value = new Date().getFullYear();
      el.fieldJumlah.value = 1;
      const jenis = el.dataForm.querySelector('input[name="jenis"]:checked').value;
      el.fieldNomorUrut.value = suggestNextNomorUrut(jenis);
    }

    el.modalOverlay.hidden = false;
    el.fieldNomorUrut.focus();
  }

  function closeModal() {
    el.modalOverlay.hidden = true;
  }

  async function deleteDoc(id) {
    await fetch(`/api/documents/${id}`, { method: 'DELETE' });
    await refresh();
  }

  async function handleSubmit(e) {
    e.preventDefault();
    el.formError.hidden = true;

    const jenis = el.dataForm.querySelector('input[name="jenis"]:checked').value;
    const keterangan = [...el.dataForm.querySelectorAll('input[name="keterangan"]:checked')].map((cb) => cb.value);

    const payload = {
      jenis,
      nomorUrut: Number(el.fieldNomorUrut.value),
      nomorBuku: el.fieldNomorBuku.value,
      kode: el.fieldKode.value,
      indeks: el.fieldIndeks.value,
      uraianMasalah: el.fieldUraian.value,
      tahun: Number(el.fieldTahun.value),
      jumlah: Number(el.fieldJumlah.value),
      keterangan,
    };

    const id = el.fieldId.value;
    const url = id ? `/api/documents/${id}` : '/api/documents';
    const method = id ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const body = await res.json();
      if (!res.ok) {
        el.formError.textContent = (body.errors || ['Gagal menyimpan data.']).join(' ');
        el.formError.hidden = false;
        return;
      }
      closeModal();
      await refresh();
    } catch (err) {
      el.formError.textContent = 'Tidak dapat terhubung ke server.';
      el.formError.hidden = false;
    }
  }

  // ---- Export & Print ----

  function csvEscape(value) {
    const str = String(value ?? '');
    if (/[",\r\n]/.test(str)) return `"${str.replace(/"/g, '""')}"`;
    return str;
  }

  function exportCsv() {
    const filtered = getFiltered();
    if (!filtered.length) {
      alert('Tidak ada data untuk diexport.');
      return;
    }
    const headers = ['No', 'Jenis', 'No. Urut', 'No. Buku', 'Kode', 'Indeks', 'Uraian Masalah', 'Tahun', 'Jumlah', 'Keterangan'];
    const rows = filtered.map((d, i) => [
      i + 1,
      d.jenis === 'masuk' ? 'Masuk' : 'Keluar',
      d.nomorUrut,
      d.nomorBuku,
      d.kode,
      d.indeks,
      d.uraianMasalah,
      d.tahun,
      d.jumlah,
      (d.keterangan || []).join(', '),
    ]);
    const csv = [headers, ...rows].map((r) => r.map(csvEscape).join(',')).join('\r\n');
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const stamp = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `arsip-surat-${stamp}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  function printTable() {
    const filtered = getFiltered();
    el.tableBody.innerHTML = filtered.length
      ? filtered.map((doc, i) => rowHtml(doc, i + 1)).join('')
      : '<tr><td colspan="11" class="empty-row">Tidak ada data.</td></tr>';
    window.print();
    renderTable();
  }

  // ---- Event wiring ----

  document.querySelectorAll('.tab').forEach((tab) => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach((t) => {
        t.classList.remove('is-active');
        t.setAttribute('aria-selected', 'false');
      });
      tab.classList.add('is-active');
      tab.setAttribute('aria-selected', 'true');
      state.jenis = tab.dataset.jenis;
      state.page = 1;
      renderTable();
    });
  });

  let searchTimer;
  el.searchInput.addEventListener('input', (e) => {
    clearTimeout(searchTimer);
    const value = e.target.value;
    searchTimer = setTimeout(() => {
      state.q = value.trim();
      state.page = 1;
      renderTable();
    }, 150);
  });

  el.filterTahun.addEventListener('change', (e) => {
    state.tahun = e.target.value;
    state.page = 1;
    renderTable();
  });

  document.getElementById('btnAdd').addEventListener('click', () => openModal(null));
  document.getElementById('btnExport').addEventListener('click', exportCsv);
  document.getElementById('btnPrint').addEventListener('click', printTable);
  document.getElementById('btnCloseModal').addEventListener('click', closeModal);
  document.getElementById('btnCancel').addEventListener('click', closeModal);
  el.modalOverlay.addEventListener('click', (e) => {
    if (e.target === el.modalOverlay) closeModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !el.modalOverlay.hidden) closeModal();
  });
  el.dataForm.addEventListener('submit', handleSubmit);
  el.dataForm.querySelectorAll('input[name="jenis"]').forEach((radio) => {
    radio.addEventListener('change', refreshSuggestionIfAdding);
  });
  el.fieldTahun.addEventListener('input', refreshSuggestionIfAdding);

  el.tableBody.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-action]');
    if (!btn) return;
    const doc = state.all.find((d) => d.id === btn.dataset.id);
    if (!doc) return;
    if (btn.dataset.action === 'edit') {
      openModal(doc);
    } else if (btn.dataset.action === 'delete') {
      if (confirm(`Hapus data "${doc.uraianMasalah}"? Tindakan ini tidak bisa dibatalkan.`)) {
        deleteDoc(doc.id);
      }
    }
  });

  refresh();
})();
