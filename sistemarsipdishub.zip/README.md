# Sistem Arsip Berkas & Surat — Dinas Perhubungan

Aplikasi web sederhana untuk mencatat dan mengelola **berkas/surat masuk dan keluar**,
sebagai pengganti pencatatan manual di spreadsheet. Dibuat untuk keperluan tugas PKL
(pemutakhiran sistem pengentrian data berkas Dinas Perhubungan).

## Fitur

- Input, edit, dan hapus data surat masuk & keluar
- Kolom data sesuai format buku agenda/arsip kantor:
  1. **Nomor** — a. Urut, b. Buku
  2. **Kode** (kode klasifikasi)
  3. **Indeks**
  4. **Uraian Masalah**
  5. **Tahun**
  6. **Jumlah**
  7. **Keterangan** — bisa Asli / Fotocopy / TTD (bisa dipilih lebih dari satu)
- Nomor urut otomatis disarankan (melanjutkan nomor terakhir di tahun & jenis yang sama)
- Filter berdasarkan jenis (Masuk/Keluar) dan tahun, serta pencarian bebas
- Ringkasan jumlah data (total, masuk, keluar, tahun berjalan)
- Export data ke CSV (bisa dibuka langsung di Excel)
- Cetak/print langsung dari browser
- Data tersimpan di server (file), sehingga bisa diakses banyak komputer sekaligus dalam satu jaringan kantor

## Struktur Proyek

```
server.js         Server backend (Express) + REST API
lib/store.js      Modul baca/tulis data (file JSON)
seed.js           Skrip opsional untuk mengisi beberapa contoh data
public/           Tampilan web (HTML, CSS, JS)
data/documents.json   Tempat data tersimpan (dibuat otomatis, tidak ikut di-commit ke git)
```

## Persyaratan

- [Node.js](https://nodejs.org/) versi 18 ke atas (pilih versi **LTS**). Cek dengan `node -v`.

## Cara Menjalankan

```bash
npm install     # sekali saja, saat pertama kali setup
npm start       # menjalankan aplikasi
```

Setelah berjalan, buka browser ke:

```
http://localhost:3000
```

(Opsional) Untuk mengisi beberapa contoh data agar tampilan tidak kosong saat pertama dicoba:

```bash
npm run seed
```

## Menggunakan dari Komputer Lain (Satu Jaringan Kantor)

Aplikasi ini bisa dijalankan di **satu komputer/laptop** di kantor, lalu diakses oleh
komputer lain yang tersambung ke WiFi/jaringan yang sama — tanpa perlu internet.

1. Di komputer yang menjalankan `npm start`, cari alamat IP lokalnya, misalnya dengan `ipconfig` (Windows) lalu lihat "IPv4 Address" (contoh: `192.168.1.10`).
2. Dari komputer lain, buka browser ke `http://192.168.1.10:3000` (ganti sesuai IP tadi).
3. Pastikan Windows Firewall mengizinkan koneksi masuk ke port 3000 saat muncul prompt izin pertama kali.

Cara ini paling praktis untuk pemakaian internal dinas karena data tidak perlu keluar dari kantor.

## Backup Data

Semua data tersimpan dalam satu file: `data/documents.json`. Untuk backup, cukup salin
file ini secara berkala (misalnya ke flashdisk atau Google Drive).

## Kalau Ingin Bisa Diakses dari Luar Kantor (Online)

Karena datanya berupa arsip surat dinas, disarankan tetap dijalankan **secara lokal di kantor**
seperti di atas. Namun jika suatu saat ingin bisa diakses dari luar (misalnya oleh pimpinan dari
rumah), aplikasi ini juga bisa di-deploy ke layanan hosting yang mendukung Node.js, misalnya
Railway, Render, atau VPS milik dinas/pemda. Perlu diperhatikan: layanan gratis biasanya
menghapus file saat aplikasi di-redeploy, sehingga untuk pemakaian jangka panjang secara online
sebaiknya minta admin/IT dinas menyediakan server atau disk penyimpanan permanen.

## Pengembangan Lanjutan (Opsional)

Beberapa hal yang bisa ditambahkan kalau aplikasi ini mau dikembangkan lebih lanjut:

- Login/hak akses per pengguna
- Unggah lampiran hasil scan surat (PDF/gambar)
- Backup otomatis terjadwal
- Riwayat perubahan data (log audit)
